## Automatically block suspicious traffic with AWS Network Firewall and Amazon GuardDuty

This repository contains sample code referenced in the blog post "Automatically block suspicious traffic with AWS Network Firewall and Amazon GuardDuty".  

## Security

See [CONTRIBUTING](CONTRIBUTING.md#security-issue-notifications) for more information.

## License

This library is licensed under the MIT-0 License. See the LICENSE file.

